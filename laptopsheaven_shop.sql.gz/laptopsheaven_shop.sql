-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 24, 2019 at 10:38 PM
-- Server version: 5.6.41
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laptopsheaven_shop`
--
CREATE DATABASE IF NOT EXISTS `laptopsheaven_shop` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `laptopsheaven_shop`;

-- --------------------------------------------------------

--
-- Table structure for table `basket`
--

CREATE TABLE `basket` (
  `id_basket` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_item` int(11) NOT NULL,
  `item_count` int(11) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `id_order` int(11) DEFAULT NULL COMMENT 'номер заказа, по умолчанию NULL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `basket`
--

INSERT INTO `basket` (`id_basket`, `id_user`, `id_item`, `item_count`, `price`, `id_order`) VALUES
(13, 2, 4, 3, '92970.00', 1),
(14, 2, 5, 1, '40990.00', 1),
(15, 2, 5, 1, '40990.00', 2),
(16, 3, 4, 1, '30990.00', 3),
(17, 2, 4, 1, '30990.00', 3),
(18, 2, 1, 1, '50000.00', 4);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id_feedback` int(11) NOT NULL,
  `author_name` varchar(255) DEFAULT NULL,
  `author_email` varchar(255) DEFAULT NULL,
  `author_message` text,
  `feedback_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id_feedback`, `author_name`, `author_email`, `author_message`, `feedback_datetime`) VALUES
(1, 'ivan', 'ivan@gg.ru', 'test', '2018-09-08 10:27:42'),
(2, 'ivan', 'ivan@gg.ru', 'test', '2018-09-08 10:29:02'),
(3, 'Олег', 'oleg@oleg.ru', 'Привет! Проверка сохранения сообщения', '2018-09-08 10:41:10'),
(4, 'Петр', 'peter@peter.ru', 'Привет! Сообщения сохраняются', '2018-09-08 10:47:31'),
(5, 'Vasiliy', 'vasiliya@gggg.ru', 'Надо добавить капчу', '2018-09-08 10:48:21'),
(6, 'Герасим', 'gerasim@ko.ru', 'Проверка сохранения сообщения после ревью кода', '2018-09-11 16:30:01'),
(7, 'Герасим2', 'gerasim2@ff.ru', 'Еще одна проверка', '2018-09-11 16:31:40'),
(8, 'Test', 'test@gg.ru', 'Тестирование2', '2018-09-19 09:03:37'),
(9, 'Test', 'test@gg.ru', 'Тестирование2', '2018-09-19 09:12:30'),
(10, 'Test', 'test@gg.ru', 'Тестирование2', '2018-09-19 09:13:43'),
(11, 'Egor', 'egor@list.ru', 'Egor Egor', '2018-09-19 09:14:05'),
(12, 'Test1', 'test@rmeila.ru', 'fsffdsfsdfgdsgf', '2018-09-19 09:26:16'),
(13, 'tester1', 'tester@mail.com', 'Tester test message', '2019-01-12 08:59:11'),
(14, 'Tester2', 'tester2@mail.com', 'Tester2 test message', '2019-01-12 09:03:17');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id_item` int(11) NOT NULL,
  `item_name` text NOT NULL COMMENT 'название товара',
  `id_img_item` int(11) NOT NULL COMMENT 'ID из таблицы item_img',
  `item_desc_short` text NOT NULL COMMENT 'короткое описание товара',
  `item_desc_full` text NOT NULL COMMENT 'полное описание товара',
  `item_price` decimal(11,2) NOT NULL COMMENT 'цена товара',
  `item_work_time` int(11) NOT NULL COMMENT 'время работы от батареи',
  `item_capacity` decimal(11,2) NOT NULL COMMENT 'емкость батареи',
  `item_battery_type` varchar(255) NOT NULL COMMENT 'тип аккумуляторов',
  `item_resolution` varchar(255) NOT NULL COMMENT 'разрешение экрана',
  `item_cpu` varchar(255) NOT NULL COMMENT 'модель процессора',
  `item_cpu_freq` int(11) NOT NULL COMMENT 'MHz',
  `item_cpu_core_count` int(11) NOT NULL COMMENT 'количество ядер',
  `item_gpu_type` varchar(255) NOT NULL COMMENT 'тип видеокарты',
  `item_gpu` varchar(255) NOT NULL COMMENT 'модель видеокарты',
  `item_os` varchar(255) NOT NULL COMMENT 'операционная система',
  `item_hdd_type` varchar(255) NOT NULL COMMENT 'тип жесткого диска',
  `item_weight` decimal(11,2) NOT NULL COMMENT 'вес товара',
  `item_isarchive` int(11) NOT NULL DEFAULT '0' COMMENT 'в архиве',
  `item_issale` int(11) NOT NULL DEFAULT '0' COMMENT 'товар участвует в акции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id_item`, `item_name`, `id_img_item`, `item_desc_short`, `item_desc_full`, `item_price`, `item_work_time`, `item_capacity`, `item_battery_type`, `item_resolution`, `item_cpu`, `item_cpu_freq`, `item_cpu_core_count`, `item_gpu_type`, `item_gpu`, `item_os`, `item_hdd_type`, `item_weight`, `item_isarchive`, `item_issale`) VALUES
(1, 'Ноутбук Apple MacBook Pro 13 with Retina display Mid 2017', 1, 'Невероятно тонкий и лёгкий MacBook Pro стал ещё быстрее и мощнее. У него самый яркий экран и лучшая цветопередача среди всех ноутбуков Mac. В клавиатуру встроена выполненная из стекла сенсорная панель Touch Bar, которая поддерживает жесты Multi‑Touch и обеспечивает быстрый и удобный доступ к тем функциям, которые нужны вам именно сейчас. MacBook Pro создан на основе самых передовых идей. И у него есть всё для воплощения ваших.', '<p>Очень долго верхнюю строку клавиатуры занимали функциональные клавиши. Пришло время заменить их более универсальным и удобным элементом управления — сенсорной панелью Touch Bar.2 В зависимости от того, чем вы занимаетесь, на ней автоматически отображаются те или иные инструменты — например, знакомые вам регуляторы громкости и яркости, функции управления фото и видео, предиктивного ввода текста и многие другие. На Mac появилась технология Touch ID. С ней вы можете мгновенно входить в свои учётные записи, а также оплачивать покупки с помощью Apple Pay — быстро и безопасно.</p>\r\n<p>Теперь можно мгновенно разблокировать свой Mac. Использовать Apple Pay для безопасной оплаты онлайн-покупок. Быстро получать доступ к системным настройкам и заметкам, защищённым паролем. И одним касанием переключаться между учётными записями.</p>\r\n<p>Touch Bar позволяет совершенно по‑новому работать с привычными приложениями — Photoshop, Microsoft Office, DaVinci Resolve, Logic Pro X и другими. Основные инструменты и функции появляются прямо на Touch Bar — вам будет удобнее найти их и начать ими пользоваться. Эта многофункциональная технология даёт разработчикам возможность делать свои новые и существующие приложения гораздо более интерактивными.</p>\r\n<p>Новый MacBook Pro задаёт совершенно новые стандарты мощности и портативности ноутбуков. Даже самые грандиозные идеи легко воплотить в жизнь с помощью передовых графических процессоров, супербыстрых накопителей и других возможностей этого MacBook Pro.</p>\r\n<p>Во всех конфигурациях 15‑дюймовый MacBook Pro оснащается мощным дискретным графическим процессором Radeon Pro. Он создан с применением передовой 14‑нанометровой технологии производства и представляет собой уникальное сочетание производительности и энергоэффективности. Теперь на всех моделях старшей конфигурации по умолчанию установлены 4 ГБ памяти GDDR5. Она создана для плавной работы в режиме реального времени даже при решении таких сложных профессиональных задач, как рендеринг 3D‑титров в Final Cut Pro X. Кроме того, во все 13‑дюймовые модели встроен графический процессор с 64 МБ интегрированной памяти DRAM — для дополнительного ускорения обработки графики. А значит, у вас останется ещё больше времени, чтобы творить и воплощать.</p>', '50000.00', 10, '54.50', 'Li-Pol', '2560x1600', 'Core i5', 2300, 2, 'встроенная', 'Intel Iris Plus Graphics 640', 'MacOS X', 'SSD', '1.37', 0, 0),
(2, 'Ноутбук Lenovo IdeaPad 320 15 Intel', 2, 'Каждая деталь Lenovo IdeaPad 320 (15\", Intel 6th Gen) создана для того, чтобы облегчить жизнь пользователя. Ноутбук с легкостью справляется с любыми задачами благодаря мощному процессору и дискретной видеокарте. На нем предустановлена ОС Windows 10 Домашняя с личным помощником Cortana.', '<p>Cortana умеет запускать приложения и искать информацию по запросам, введенным вручную или с помощью голосовых команд. Наслаждайся простотой и лаконичностью Lenovo IdeaPad 320 (15\", Intel 6th Gen) в каждой детали — от нового элегантного дизайна до удобного интерфейса рабочего стола. Самая сложная проблема, с которой предстоит столкнуться, — выбрать цвет ноутбука.</p>\r\n\r\n<p>Поддержка лучшего на сегодняшний день процессора Intel® Core™ i7 6-го поколения и памяти DDR4 до 12 ГБ гарантирует высокое быстродействие и стабильную производительность. Запускай одновременно множество программ, с легкостью переключайся между вкладками веб-браузера и наслаждайся многозадачностью без помех.</p>\r\n\r\n<p>Мы полностью изменили дизайн модели Lenovo IdeaPad 320 (15\", Intel 6th Gen). Теперь она представлена в элегантном цельном корпусе привлекательных расцветок: платиновый серый, черный оникс, сверкающий белый, джинсовый синий, сливовый, коралловый. Ноутбук Lenovo IdeaPad 320 (15\", Intel 6th Gen) создан для решения самых разных задач. Он защищен специальным износостойким покрытием, устойчивым к бытовым повреждениям, а также прорезиненными деталями снизу, которые обеспечивают максимальную вентиляцию и продлевают срок службы изделия.</p>\r\n\r\n<p>Lenovo IdeaPad 320 (15\", Intel 6th Gen) поддерживает широкий спектр видеокарт, включая мощную видеокарту NVIDIA® GeForce™ 920MX. Дискретные видеокарты используют собственные вычислительные ресурсы, что повышает качество изображения, уменьшает количество разрывов кадров, увеличивает производительность в играх без ущерба для быстродействия и отклика системы. Наслаждайся качественным изображением в компьютерной игре или при создании и редактировании различного контента.</p>\r\n\r\n<p>В максимальной комплектации ноутбук Lenovo IdeaPad 320 (15\", Intel 6th Gen) поддерживает дисплей стандарта Full HD с антибликовым покрытием. Ты по достоинству оценишь четкость и реалистичность изображения при просмотре фильмов и веб-серфинге.</p>', '45991.00', 6, '80.50', 'Li-Ion', '1920x1080', 'Core i7', 32700, 4, 'дискретная', 'NVIDIA GeForce MX150', 'Windows 10 Home', 'HDD+SSD', '2.20', 0, 0),
(3, 'Ноутбук DELL INSPIRON 5570', 3, 'Ноутбук с диагональю 15\" обеспечивает исключительное качество изображения, отличается потрясающим дизайном и оснащен целым рядом функций для полной свободы развлечений в любом месте.', '<p>Предельная четкость. Оцените высочайшую четкость и детализацию изображения на несенсорном дисплее с диагональю 15,6\", разрешением Full HD и антибликовым покрытием. Откройте новый уровень взаимодействия за счет опционального сенсорного экрана.</p>\r\n\r\n<p>Максимальная производительность. Новейший процессор Intel® Core™ i обеспечивает высокую производительность при компактных размерах. Благодаря увеличенной производительности, расширенной пропускной способности, невероятной энергоэффективности и до 16 Гбайт памяти DDR4 вы сразу же сможете работать с приложениями и одновременно выполнять несколько задач на профессиональном уровне. Оцените непревзойденную плавность изображения в играх, а также оптимальную дополнительную производительность для ежедневных задач благодаря опциональному выделенному графическому адаптеру с памятью GDDR5 объемом до 4 Гбайт. Этот ноутбук обеспечивает несколько вариантов конфигурации накопителей для максимальной производительности и полноценного резервного копирования, включая жесткий диск емкостью до 2 Тбайт, твердотельный накопитель емкостью до 256 Гбайт, конфигурацию с двумя накопителями и твердотельный накопитель NVME.</p>\r\n\r\n<p>Порт USB Type C 3.1 обеспечивает удобное и быстрое подключение: он заряжает устройство, подключается к сети Ethernet, а также поддерживает вывод аудио- и видеосигнала. Доступно только на системах с выделенным графическим адаптером.</p>\r\n\r\n<p>Технология Windows Hello и опциональное устройство считывания отпечатков пальцев на кнопке включения обеспечивают предельно удобный и безопасный вход в систему даже для нескольких пользователей.</p>\r\n\r\n<p>Заряда мощного аккумулятора ноутбука Inspiron хватит на весь день. Время работы без подзарядки тестируется с использованием ставшего отраслевым стандартом приложения MobileMark 2014. Время работы без подзарядки зависит от конфигурации продукта, используемого программного обеспечения, стиля работы, условий эксплуатации и параметров системы.</p>', '35990.00', 8, '42.00', 'Li-Pol', '1920x1080', 'Core i7', 2400, 4, 'дискретная и встроенная', 'Intel HD Graphics 520', 'Windows 10 Home', 'HDD+SSD', '2.02', 0, 0),
(4, 'Ноутбук Xiaomi Mi Notebook Air 12.5', 4, 'Mi Notebook Air – первый ноутбук от китайской компании Xiaomi. Корпус выглядит стильно, дорого и оставляет приятные ощущения во время работы. Он изготовлен из алюминия, стекла и высококачественного пластика. Модель собрана идеально, не имеет зазоров и работает тихо.', '<p>Благодаря плотному размещению компонентов, материнской платы и специальной технологии соединения деталей компания Xiaomi смогла сделать Mi Notebook Air еще тоньше. Благодаря использованию батареи высокой плотности устройство потребляет минимальное количество энергии, кроме того, такая батарея занимает очень мало места. Внедрение этих новшеств позволило Xiaomi создать линейку портативных ноутбуков, которые сочетают в себе высокую производительность и компактные размеры. Mi Notebook Air легко помещается практически в любой сумке или рюкзаке, его легко носить с собой даже в одной руке, и он всегда привлекает к себе внимание, благодаря своему стильному внешнему виду.</p>\r\n\r\n<p>Xiaomi стремится достичь максимальных высот даже в мелочах. Высокопроизводительный процессор от Intel, быстрый диск SSD, графической картой Intel HD Graphics 515 — это залог успеха. Играйте в мощные современные игры, создавайте и редактируйте видео без каких — либо проблем и задержек. Вам больше не придется выбирать между портативностью и функциональностью.</p>\r\n\r\n<p>Такой маленький ноутбук с таким длительным временем автономной работы — это не волшебство, это наука. Для этого Xiaomi использует батареи с высокой плотностью энергии 600 Вт*ч/л, что делает аккумулятор очень легким и позволяет использовать быструю зарядку через порт USB Type-C. Теперь можно заряжать ноутбук на 50% всего за полчаса. Mi Notebook Air удобно использовать в любое время и в любом месте — дома, на прогулке или во время путешествия</p>', '30990.00', 5, '37.50', 'Li-Pol', '1920x1080', 'Core M3', 900, 2, 'встроенная', 'Intel Iris Plus Graphics 640', 'Windows 10 Home', 'SSD', '1.07', 0, 1),
(5, 'Ноутбук HP 250 G6', 5, 'Ноутбук HP 250 отличается выгодной ценой и позволяет всегда оставаться на связи. Ноутбук HP 250 на базе ОС Windows 10 Pro1 — это отличное средство для решения любых задач. Он объединяет в себе технологии Intel® и все необходимое для совместной работы. Прочный корпус ноутбука надежно защищает его от повреждений при переноске.', '<p>Будьте уверены — HP 250 способен выполнять срочные задачи на ходу. Прочный корпус обеспечивает надежную защиту ноутбука и придает ему деловой внешний вид, соответствующий вашему стилю.</p>\r\n\r\n<p>Оцените преимущества Windows 10 Pro и мощность новейших процессоров Intel® Core™ i5/i7 7-го поколения с дополнительной памятью DDR4.</p>\r\n\r\n<p>Некоторые вопросы можно решить только в личной беседе. Благодаря дополнительной веб-камере HP HD с широким динамическим диапазоном на виртуальных встречах вы будете выглядеть наилучшим образом даже при плохом освещении. Быстрое подключение к периферийным устройствам в офисе или дома с помощью традиционных разъемов RJ-45 и VGA. Ноутбук HP 250 оснащен слотом для карт памяти SD. С его помощью можно удобно переносить данные и сохранять их резервные копии.</p>\r\n\r\n<p>Компания HP — мировой лидер на рынке персональных компьютеров — представляет полнофункциональный ноутбук для решения любых задач, который поддерживает подключение дополнительных устройств3 и оснащен разъемами RJ-45 и VGA.</p>', '40990.00', 3, '31.00', 'Li-Pol', '1920x1080', 'Core i3', 2700, 2, 'встроенная', 'Intel HD Graphics 405', 'Без ОС', 'SSD', '1.86', 0, 1),
(6, 'test', 6, 'test2', 'test3', '111111.00', 1, '1.00', 'test4', 'test5', 'test6', 1, 1, 'test7', 'test8', 'test9', 'test10', '1.00', 1, 0),
(7, 'testItem', 7, 'testItem testItem', '<p>testItem testItem testItem</p>', '1.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 1, 0),
(8, 'itemTest', 8, 'itemTest', 'itemTest', '1.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 1, 0),
(9, 'testItem3', 9, 'testItem3', 'testItem3', '1.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 1, 0),
(10, 'laptop 01', 10, '1', '1', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(11, 'laptop 02', 11, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(12, 'laptop 03', 12, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(13, 'laptop 04', 13, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(14, 'laptop 05', 14, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(15, 'laptop 06', 15, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(16, 'laptop 07', 16, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(17, 'laptop 08', 17, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(18, 'laptop 09', 18, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(19, 'laptop 10', 19, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(20, 'laptop 11', 20, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(21, 'laptop 12', 21, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0),
(22, 'laptop 13', 22, 'testItem3', 'testItem3', '15000.00', 1, '1.00', '1', '1', '1', 1, 1, '1', '1', '1', '1', '1.00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_img`
--

CREATE TABLE `item_img` (
  `id_img_item` int(11) NOT NULL,
  `img` text NOT NULL COMMENT 'путь до полной версии изображения',
  `img_min` text NOT NULL COMMENT 'путь до превью'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item_img`
--

INSERT INTO `item_img` (`id_img_item`, `img`, `img_min`) VALUES
(1, '../public/item_img/laptop_01_full_100763.jpg', '../public/item_img/laptop_01_full_100763_min.jpg'),
(2, '../public/item_img/laptop_02_full_63711.jpg', '../public/item_img/laptop_02_full_63711_min.jpg'),
(3, '../public/item_img/laptop_03_full_82956.jpg', '../public/item_img/laptop_03_full_82956_min.jpg'),
(4, '../public/item_img/laptop_04_full_18615.jpg', '../public/item_img/laptop_04_full_18615_min.jpg'),
(5, '../public/item_img/laptop_05_full_71679.jpg', '../public/item_img/laptop_05_full_71679_min.jpg'),
(6, '../public/item_img/57638.jpg', '../public/item_img/57638_min.jpg'),
(7, '../public/item_img/15822.jpg', '../public/item_img/15822_min.jpg'),
(8, '../public/item_img/koala_95212.jpg', '../public/item_img/koala_95212_min.jpg'),
(9, '../public/item_img/koala_107757.jpg', '../public/item_img/koala_107757_min.jpg'),
(10, '../public/item_img/laptop-icon_101595.jpg', '../public/item_img/laptop-icon_101595_min.jpg'),
(11, '../public/item_img/laptop-icon_101596.jpg', '../public/item_img/laptop-icon_101596_min.jpg'),
(12, '../public/item_img/laptop-icon_101597.jpg', '../public/item_img/laptop-icon_101597_min.jpg'),
(13, '../public/item_img/laptop-icon_101598.jpg', '../public/item_img/laptop-icon_101598_min.jpg'),
(14, '../public/item_img/laptop-icon_101599.jpg', '../public/item_img/laptop-icon_101599_min.jpg'),
(15, '../public/item_img/laptop-icon_101600.jpg', '../public/item_img/laptop-icon_101600_min.jpg'),
(16, '../public/item_img/laptop-icon_101601.jpg', '../public/item_img/laptop-icon_101601_min.jpg'),
(17, '../public/item_img/laptop-icon_101602.jpg', '../public/item_img/laptop-icon_101602_min.jpg'),
(18, '../public/item_img/laptop-icon_101603.jpg', '../public/item_img/laptop-icon_101603_min.jpg'),
(19, '../public/item_img/laptop-icon_101604.jpg', '../public/item_img/laptop-icon_101604_min.jpg'),
(20, '../public/item_img/laptop-icon_101605.jpg', '../public/item_img/laptop-icon_101605_min.jpg'),
(21, '../public/item_img/laptop-icon_101606.jpg', '../public/item_img/laptop-icon_101606_min.jpg'),
(22, '../public/item_img/laptop-icon_101607.jpg', '../public/item_img/laptop-icon_101607_min.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id_order` int(11) NOT NULL,
  `id_order_status` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'дата создания заказа',
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'последняя дата изменения заказа'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id_order`, `id_order_status`, `id_user`, `create_date`, `modify_date`) VALUES
(1, 1, 2, '2019-01-14 06:32:38', '2019-01-14 06:32:38'),
(2, 3, 2, '2019-01-14 07:20:59', '2019-01-15 07:20:59'),
(3, 4, 2, '2019-01-15 12:12:06', '2019-01-15 12:12:06'),
(4, 2, 2, '2019-01-17 19:02:04', '2019-01-17 19:02:04');

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id_status` int(11) NOT NULL,
  `order_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`id_status`, `order_status`) VALUES
(1, 'Новый'),
(2, 'Принят'),
(3, 'Выполнен'),
(4, 'Отменён');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL COMMENT 'user ID',
  `user_email` varchar(255) NOT NULL COMMENT 'user email',
  `user_pass` varchar(255) NOT NULL COMMENT 'user password (hash)',
  `user_date_created` timestamp NOT NULL COMMENT 'дата и время создания пользователя',
  `user_date_modify` timestamp NOT NULL COMMENT 'датав и время изменений в аккаунте пользователя',
  `id_role` int(11) NOT NULL COMMENT 'ID роли пользователя',
  `user_isactive` int(11) NOT NULL DEFAULT '1' COMMENT '1 - пользователь активен, 0 - пользователь отключен',
  `user_comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `user_email`, `user_pass`, `user_date_created`, `user_date_modify`, `id_role`, `user_isactive`, `user_comment`) VALUES
(1, 'admin@lp.test', 'c484731969b767820934f6fb74a803f05b382e4b5b10383f6819a5374fcda0fb8d0d7e14f9cf6ef8f76d406669c081821fc6f32d068e98b3f831b163c8a0f84b', '2018-09-16 19:32:33', '2018-09-16 19:32:33', 1, 1, ''),
(2, 'user@lp.test', 'cb9d82a4a545e4f930fbc3a4eed76240030656f1e6cb6bf3acc0f6c1642fea9fac21d08af7085299631bc4faff5f501d1f9993dc762e18df8c3968bc47faf537', '2018-09-20 06:11:21', '2018-09-20 06:11:21', 2, 1, ''),
(3, 'user2@lp.test', 'af3f2e754a84b41b87105f8d3f6c3695ac7f0afd49529a4ff8adc01a730d9b16e0ed00c157d6bf3bf83530759917dfc85b6e519210adc4e92298d69092ddddc5', '2018-09-20 06:29:06', '2018-09-20 06:29:06', 2, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id_user_role` int(11) NOT NULL COMMENT 'ID роли',
  `user_role_name` varchar(255) NOT NULL COMMENT 'Название роли'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id_user_role`, `user_role_name`) VALUES
(1, 'admin'),
(2, 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`id_basket`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id_feedback`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id_item`);

--
-- Indexes for table `item_img`
--
ALTER TABLE `item_img`
  ADD PRIMARY KEY (`id_img_item`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`,`id_order_status`,`id_user`,`create_date`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id_user_role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `basket`
--
ALTER TABLE `basket`
  MODIFY `id_basket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id_feedback` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `item_img`
--
ALTER TABLE `item_img`
  MODIFY `id_img_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT COMMENT 'user ID', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id_user_role` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID роли', AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
